(function() {
  'use strict';
  
  angular
    .module('testApp')
    .controller('EmpDetailsCtrl', ['$scope', EmpDetailsCtrl]);
  
  function EmpDetailsCtrl(scope) {
  }
}());